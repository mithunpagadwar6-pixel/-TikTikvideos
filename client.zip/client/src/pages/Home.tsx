import { useEffect, useState } from 'react';
import { Link } from 'wouter';
import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { getFirebase } from '@/lib/firebase';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Play, Eye, ThumbsUp } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface Video {
  id: string;
  title: string;
  description: string;
  category?: string;
  url: string;
  userId: string;
  views: number;
  likes: number;
  duration: number;
  isShort: boolean;
  createdAt: any;
}

export default function Home() {
  const { user } = useAuth();
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    try {
      const { db } = getFirebase();
      const videosRef = collection(db, 'videos');
      const q = query(
        videosRef,
        where('approvalStatus', '==', 'approved'),
        where('isShort', '==', false),
        orderBy('createdAt', 'desc')
      );

      const snapshot = await getDocs(q);
      const videoList: Video[] = [];
      snapshot.forEach((doc) => {
        videoList.push({ id: doc.id, ...doc.data() } as Video);
      });

      setVideos(videoList);
    } catch (error) {
      console.error('Error loading videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Discover Videos</h1>
        <p className="text-muted-foreground">Watch the latest approved videos from our community</p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="p-0">
                <Skeleton className="h-48 w-full rounded-t-lg" />
              </CardHeader>
              <CardContent className="p-4">
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-3 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : videos.length === 0 ? (
        <Card className="p-12 text-center">
          <div className="flex flex-col items-center gap-4">
            <Play className="h-16 w-16 text-muted-foreground" />
            <div>
              <h3 className="text-lg font-semibold mb-1">No videos yet</h3>
              <p className="text-sm text-muted-foreground">
                {user ? 'Be the first to upload a video!' : 'Sign in to start uploading videos'}
              </p>
            </div>
            {user && (
              <Link href="/upload">
                <a>
                  <button className="mt-2 px-4 py-2 bg-primary text-primary-foreground rounded-md">
                    Upload Video
                  </button>
                </a>
              </Link>
            )}
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {videos.map((video) => (
            <Link key={video.id} href={`/watch/${video.id}`}>
              <a data-testid={`card-video-${video.id}`}>
                <Card className="hover-elevate active-elevate-2 cursor-pointer h-full">
                  <CardHeader className="p-0">
                    <div className="relative aspect-video bg-muted rounded-t-lg overflow-hidden">
                      <video
                        src={video.url}
                        className="w-full h-full object-cover"
                        preload="metadata"
                      />
                      <div className="absolute bottom-2 right-2 bg-black/75 text-white text-xs px-2 py-1 rounded">
                        {formatDuration(video.duration)}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    <CardTitle className="text-base line-clamp-2 mb-2">{video.title}</CardTitle>
                    <CardDescription className="line-clamp-2">{video.description}</CardDescription>
                  </CardContent>
                  <CardFooter className="px-4 pb-4 flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {video.views}
                      </span>
                      <span className="flex items-center gap-1">
                        <ThumbsUp className="h-3 w-3" />
                        {video.likes}
                      </span>
                    </div>
                    {video.category && (
                      <Badge variant="secondary" className="text-xs">{video.category}</Badge>
                    )}
                  </CardFooter>
                </Card>
              </a>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
