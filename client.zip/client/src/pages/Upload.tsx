import { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { Upload as UploadIcon, Video, Clock } from 'lucide-react';

export default function Upload() {
  const { user, getIdToken } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('general');
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);

  if (!user) {
    return (
      <div className="container py-16">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Sign In Required</CardTitle>
            <CardDescription>Please sign in to upload videos</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    // Check file size (150MB max)
    if (selectedFile.size > 150 * 1024 * 1024) {
      toast({
        title: 'File Too Large',
        description: 'Maximum file size is 150MB',
        variant: 'destructive'
      });
      return;
    }

    // Check file type
    if (!selectedFile.type.startsWith('video/')) {
      toast({
        title: 'Invalid File Type',
        description: 'Please select a video file',
        variant: 'destructive'
      });
      return;
    }

    setFile(selectedFile);

    // Get video duration
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      URL.revokeObjectURL(video.src);
      setDuration(Math.floor(video.duration));
    };
    video.src = URL.createObjectURL(selectedFile);
  };

  const handleUpload = async () => {
    if (!file || !title) {
      toast({
        title: 'Missing Information',
        description: 'Please provide a file and title',
        variant: 'destructive'
      });
      return;
    }

    setUploading(true);
    setProgress(0);

    try {
      const token = await getIdToken();
      if (!token) {
        throw new Error('Not authenticated');
      }

      const formData = new FormData();
      formData.append('video', file);
      formData.append('title', title);
      formData.append('description', description);
      formData.append('category', category);
      formData.append('duration', duration.toString());

      // Determine endpoint based on duration
      const isShort = duration > 0 && duration <= 60;
      const endpoint = isShort ? '/api/upload-short' : '/api/upload-video';

      const xhr = new XMLHttpRequest();

      xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable) {
          const percentComplete = (e.loaded / e.total) * 100;
          setProgress(Math.round(percentComplete));
        }
      });

      xhr.addEventListener('load', () => {
        if (xhr.status === 200) {
          const response = JSON.parse(xhr.responseText);
          toast({
            title: 'Upload Successful!',
            description: 'Your video is pending admin approval'
          });
          setLocation('/');
        } else {
          const error = JSON.parse(xhr.responseText);
          throw new Error(error.error || 'Upload failed');
        }
      });

      xhr.addEventListener('error', () => {
        throw new Error('Network error during upload');
      });

      xhr.open('POST', endpoint);
      xhr.setRequestHeader('Authorization', `Bearer ${token}`);
      xhr.send(formData);

      await new Promise((resolve, reject) => {
        xhr.addEventListener('load', () => {
          if (xhr.status === 200) {
            resolve(true);
          } else {
            reject(new Error('Upload failed'));
          }
        });
        xhr.addEventListener('error', () => reject(new Error('Network error')));
      });

    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        title: 'Upload Failed',
        description: error.message || 'Failed to upload video',
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  return (
    <div className="container py-8">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Upload Video</CardTitle>
          <CardDescription>
            Share your video with the community. Maximum file size: 150MB
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="video-file">Video File</Label>
            <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center hover-elevate cursor-pointer">
              <input
                id="video-file"
                type="file"
                accept="video/*"
                onChange={handleFileChange}
                className="hidden"
                disabled={uploading}
                data-testid="input-video-file"
              />
              <label htmlFor="video-file" className="cursor-pointer">
                <div className="flex flex-col items-center gap-2">
                  {file ? (
                    <>
                      <Video className="h-12 w-12 text-primary" />
                      <div>
                        <p className="font-medium">{file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                          {duration > 0 && (
                            <span className="ml-2 inline-flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {Math.floor(duration / 60)}:{(duration % 60).toString().padStart(2, '0')}
                            </span>
                          )}
                        </p>
                      </div>
                    </>
                  ) : (
                    <>
                      <UploadIcon className="h-12 w-12 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Click to select video</p>
                        <p className="text-sm text-muted-foreground">or drag and drop</p>
                      </div>
                    </>
                  )}
                </div>
              </label>
            </div>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="Give your video a title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={uploading}
              data-testid="input-title"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your video"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              disabled={uploading}
              rows={4}
              data-testid="input-description"
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label htmlFor="category">Category</Label>
            <Select value={category} onValueChange={setCategory} disabled={uploading}>
              <SelectTrigger id="category" data-testid="select-category">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="entertainment">Entertainment</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="music">Music</SelectItem>
                <SelectItem value="gaming">Gaming</SelectItem>
                <SelectItem value="sports">Sports</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="lifestyle">Lifestyle</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Upload Progress */}
          {uploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Uploading...</span>
                <span>{progress}%</span>
              </div>
              <Progress value={progress} data-testid="progress-upload" />
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button
              onClick={handleUpload}
              disabled={!file || !title || uploading}
              className="flex-1"
              data-testid="button-upload"
            >
              {uploading ? 'Uploading...' : 'Upload Video'}
            </Button>
            <Button
              variant="outline"
              onClick={() => setLocation('/')}
              disabled={uploading}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
          </div>

          {duration > 0 && duration <= 60 && (
            <p className="text-sm text-muted-foreground text-center">
              This video will be uploaded as a Short (60 seconds or less)
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
