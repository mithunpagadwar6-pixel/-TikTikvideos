import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { getFirebase, googleProvider, initializeFirebase } from '@/lib/firebase';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  getIdToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [firebaseInitialized, setFirebaseInitialized] = useState(false);
  const { toast } = useToast();

  // Initialize Firebase on mount
  useEffect(() => {
    initializeFirebase()
      .then(() => {
        setFirebaseInitialized(true);
      })
      .catch((error) => {
        console.error('Firebase initialization error:', error);
        toast({
          title: 'Initialization Error',
          description: 'Failed to initialize Firebase. Please refresh the page.',
          variant: 'destructive'
        });
      });
  }, [toast]);

  // Check admin status
  const checkAdminStatus = async (userId: string) => {
    try {
      const { db } = getFirebase();
      
      // Check userRoles collection
      const roleDoc = await getDoc(doc(db, 'userRoles', userId));
      if (roleDoc.exists() && roleDoc.data()?.role === 'admin') {
        return true;
      }

      // Check users collection
      const userDoc = await getDoc(doc(db, 'users', userId));
      if (userDoc.exists() && userDoc.data()?.isAdmin === true) {
        return true;
      }

      return false;
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  };

  // Auth state listener
  useEffect(() => {
    if (!firebaseInitialized) return;

    const { auth, db } = getFirebase();

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);

      if (firebaseUser) {
        // Check admin status
        const adminStatus = await checkAdminStatus(firebaseUser.uid);
        setIsAdmin(adminStatus);

        // Create/update user document in Firestore
        try {
          const userRef = doc(db, 'users', firebaseUser.uid);
          const userDoc = await getDoc(userRef);
          
          if (!userDoc.exists()) {
            await setDoc(userRef, {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: firebaseUser.displayName,
              photoURL: firebaseUser.photoURL,
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            });
          } else {
            await setDoc(userRef, {
              email: firebaseUser.email,
              displayName: firebaseUser.displayName,
              photoURL: firebaseUser.photoURL,
              updatedAt: new Date().toISOString()
            }, { merge: true });
          }
        } catch (error) {
          console.error('Error updating user document:', error);
        }
      } else {
        setIsAdmin(false);
      }

      setLoading(false);
    });

    return () => unsubscribe();
  }, [firebaseInitialized]);

  const signInWithGoogle = async () => {
    try {
      const { auth } = getFirebase();
      await signInWithPopup(auth, googleProvider);
      toast({
        title: 'Success',
        description: 'Signed in successfully!'
      });
    } catch (error: any) {
      console.error('Sign in error:', error);
      toast({
        title: 'Sign In Failed',
        description: error.message || 'Failed to sign in with Google',
        variant: 'destructive'
      });
    }
  };

  const signOut = async () => {
    try {
      const { auth } = getFirebase();
      await firebaseSignOut(auth);
      toast({
        title: 'Signed Out',
        description: 'You have been signed out successfully'
      });
    } catch (error: any) {
      console.error('Sign out error:', error);
      toast({
        title: 'Sign Out Failed',
        description: error.message || 'Failed to sign out',
        variant: 'destructive'
      });
    }
  };

  const getIdToken = async () => {
    if (!user) return null;
    try {
      return await user.getIdToken();
    } catch (error) {
      console.error('Error getting ID token:', error);
      return null;
    }
  };

  const value = {
    user,
    isAdmin,
    loading,
    signInWithGoogle,
    signOut,
    getIdToken
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
