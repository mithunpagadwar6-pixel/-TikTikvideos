import { getFirebaseAdmin, verifyFirebaseToken, isAdmin } from '../firebaseAdmin.js';

/**
 * Get pending videos endpoint (Admin only)
 * Returns all videos with approvalStatus: 'pending'
 */
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Verify authentication
    const decodedToken = await verifyFirebaseToken(req.headers.authorization);
    const userId = decodedToken.uid;

    // Verify admin access
    const userIsAdmin = await isAdmin(userId);
    if (!userIsAdmin) {
      return res.status(403).json({ 
        error: 'Forbidden: Admin access required',
        message: 'You do not have permission to access this resource'
      });
    }

    const { admin: adminApp } = getFirebaseAdmin();
    const firestore = adminApp.firestore();

    // Get all pending videos
    const videosSnapshot = await firestore
      .collection('videos')
      .where('approvalStatus', '==', 'pending')
      .orderBy('createdAt', 'desc')
      .get();

    const videos = [];
    for (const doc of videosSnapshot.docs) {
      const videoData = doc.data();
      
      // Get user info
      let uploaderInfo = null;
      try {
        const userDoc = await firestore.collection('users').doc(videoData.userId).get();
        if (userDoc.exists) {
          const userData = userDoc.data();
          uploaderInfo = {
            uid: videoData.userId,
            displayName: userData.displayName || userData.username || 'Unknown User',
            email: userData.email || null
          };
        }
      } catch (error) {
        console.error('Failed to fetch user info:', error.message);
      }

      videos.push({
        id: doc.id,
        ...videoData,
        uploader: uploaderInfo,
        createdAt: videoData.createdAt?.toDate().toISOString() || null
      });
    }

    res.status(200).json({
      success: true,
      count: videos.length,
      videos: videos
    });

  } catch (error) {
    console.error('Get pending videos error:', error.message);
    
    if (error.message.includes('token')) {
      return res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
    }
    
    res.status(500).json({ error: 'Failed to fetch pending videos' });
  }
}
