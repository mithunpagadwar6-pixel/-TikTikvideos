import { getFirebaseAdmin, verifyFirebaseToken, isAdmin } from '../firebaseAdmin.js';
import { parseJsonBody } from '../_lib/buffer.js';

/**
 * Reject video endpoint (Admin only)
 * Changes video approvalStatus from 'pending' to 'rejected'
 */
export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    // Verify authentication
    const decodedToken = await verifyFirebaseToken(req.headers.authorization);
    const userId = decodedToken.uid;

    // Verify admin access
    const userIsAdmin = await isAdmin(userId);
    if (!userIsAdmin) {
      res.status(403).json({ 
        error: 'Forbidden: Admin access required',
        message: 'You do not have permission to reject videos'
      });
      return;
    }

    // Parse request body with timeout
    const body = await parseJsonBody(req);
    const { videoId, reason } = body;

    if (!videoId) {
      res.status(400).json({ error: 'videoId is required' });
      return;
    }

    const { admin: adminApp } = getFirebaseAdmin();
    const firestore = adminApp.firestore();

    // Get video document
    const videoRef = firestore.collection('videos').doc(videoId);
    const videoDoc = await videoRef.get();

    if (!videoDoc.exists) {
      res.status(404).json({ error: 'Video not found' });
      return;
    }

    // Update approval status
    await videoRef.update({
      approvalStatus: 'rejected',
      rejectedBy: userId,
      rejectionReason: reason || 'No reason provided',
      rejectedAt: adminApp.firestore.FieldValue.serverTimestamp(),
      updatedAt: adminApp.firestore.FieldValue.serverTimestamp()
    });

    res.status(200).json({
      success: true,
      message: 'Video rejected successfully',
      videoId: videoId,
      approvalStatus: 'rejected',
      reason: reason || 'No reason provided'
    });

  } catch (error) {
    console.error('Reject video error:', error.message);
    
    if (error.message.includes('token')) {
      res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
    } else if (error.message.includes('timeout')) {
      res.status(408).json({ error: 'Request timeout' });
    } else {
      res.status(500).json({ error: 'Failed to reject video', details: error.message });
    }
  }
}
