import Busboy from 'busboy';
import { getFirebaseAdmin, verifyFirebaseToken } from './firebaseAdmin.js';

/**
 * Upload video endpoint
 * Streams video directly from request to Firebase Storage
 * No buffering - end-to-end streaming to prevent memory exhaustion
 */
export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader('Access-Control-Allow-Headers', 'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  // Check content length (enforce 150MB max)
  const contentLength = parseInt(req.headers['content-length'] || '0');
  if (contentLength > 150 * 1024 * 1024) {
    res.status(413).json({ error: 'File too large. Maximum size is 150MB' });
    return;
  }

  let responseSent = false;

  try {
    // Verify authentication
    const decodedToken = await verifyFirebaseToken(req.headers.authorization);
    const userId = decodedToken.uid;

    const { bucket, admin: adminApp } = getFirebaseAdmin();
    const firestore = adminApp.firestore();

    // Stream upload using Busboy
    await new Promise((resolve, reject) => {
      // Guard against warm invocations with exhausted stream
      if (req.readableEnded) {
        reject(new Error('Request stream already consumed'));
        return;
      }

      const busboy = Busboy({ headers: req.headers });
      const fields = {};
      let uploadPromise = null;

      // Collect form fields
      busboy.on('field', (fieldname, value) => {
        fields[fieldname] = value;
      });

      // Handle file upload
      busboy.on('file', (fieldname, file, info) => {
        if (fieldname !== 'video') {
          file.resume();
          return;
        }

        const { filename, mimeType } = info;
        const timestamp = Date.now();
        const sanitizedFilename = filename.replace(/[^a-zA-Z0-9.-]/g, '_');
        const storagePath = `videos/${userId}/${timestamp}_${sanitizedFilename}`;

        // Create Firebase Storage write stream
        const fileRef = bucket.file(storagePath);
        const writeStream = fileRef.createWriteStream({
          metadata: {
            contentType: mimeType,
            metadata: {
              uploadedBy: userId,
              originalName: filename
            }
          }
        });

        // Stream file directly to Firebase Storage
        uploadPromise = new Promise((resolveUpload, rejectUpload) => {
          file.pipe(writeStream)
            .on('error', (error) => {
              console.error('Write stream error:', error.message);
              rejectUpload(error);
            })
            .on('finish', async () => {
              try {
                // Make file publicly readable
                await fileRef.makePublic();
                
                // Get public URL
                const publicUrl = `https://storage.googleapis.com/${bucket.name}/${storagePath}`;
                
                resolveUpload({ storagePath, publicUrl });
              } catch (error) {
                rejectUpload(error);
              }
            });

          // Handle file stream errors
          file.on('error', (error) => {
            console.error('File stream error:', error.message);
            rejectUpload(error);
          });
        });
      });

      // Handle completion
      busboy.on('finish', async () => {
        try {
          if (!uploadPromise) {
            if (!responseSent) {
              res.status(400).json({ error: 'No video file provided' });
              responseSent = true;
            }
            resolve();
            return;
          }

          // Wait for upload to complete
          const { storagePath, publicUrl } = await uploadPromise;

          // Create video metadata in Firestore
          const videoData = {
            title: fields.title || 'Untitled Video',
            description: fields.description || '',
            category: fields.category || 'general',
            duration: parseInt(fields.duration) || 0,
            userId: userId,
            storagePath: storagePath,
            url: publicUrl,
            approvalStatus: 'pending',
            isShort: false,
            isLive: false,
            views: 0,
            likes: 0,
            createdAt: adminApp.firestore.FieldValue.serverTimestamp(),
            updatedAt: adminApp.firestore.FieldValue.serverTimestamp()
          };

          const videoRef = await firestore.collection('videos').add(videoData);

          if (!responseSent) {
            res.status(200).json({
              success: true,
              message: 'Video uploaded successfully',
              videoId: videoRef.id,
              url: publicUrl,
              approvalStatus: 'pending'
            });
            responseSent = true;
          }
          resolve();
        } catch (error) {
          reject(error);
        }
      });

      // Handle Busboy errors
      busboy.on('error', (error) => {
        console.error('Busboy error:', error.message);
        reject(error);
      });

      // Handle client abort
      req.on('aborted', () => {
        reject(new Error('Client aborted upload'));
      });

      // Pipe request directly to Busboy
      req.pipe(busboy);
    });

  } catch (error) {
    console.error('Upload video error:', error.message);
    
    if (!responseSent) {
      if (error.message.includes('token')) {
        res.status(401).json({ error: 'Unauthorized: Invalid or expired token' });
      } else if (error.message.includes('aborted')) {
        res.status(499).json({ error: 'Client aborted upload' });
      } else {
        res.status(500).json({ error: 'Failed to upload video', details: error.message });
      }
      responseSent = true;
    }
  }
}

// Disable body parser and set response limit
export const config = {
  api: {
    bodyParser: false,
    responseLimit: false
  }
};
