/**
 * Get Firebase client configuration
 * Returns Firebase config for frontend initialization
 * These values are safe to expose publicly
 */
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const config = {
      apiKey: process.env.VITE_FIREBASE_API_KEY || '',
      authDomain: `${process.env.VITE_FIREBASE_PROJECT_ID || ''}.firebaseapp.com`,
      projectId: process.env.VITE_FIREBASE_PROJECT_ID || '',
      storageBucket: process.env.FIREBASE_STORAGE_BUCKET || '',
      messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || '',
      appId: process.env.VITE_FIREBASE_APP_ID || ''
    };

    // Verify all required fields are present
    const missingFields = Object.entries(config)
      .filter(([_, value]) => !value)
      .map(([key]) => key);

    if (missingFields.length > 0) {
      return res.status(500).json({
        error: 'Firebase configuration incomplete',
        missingFields
      });
    }

    res.status(200).json(config);
  } catch (error) {
    console.error('Failed to get Firebase config:', error.message);
    res.status(500).json({ error: 'Failed to get configuration' });
  }
}
