/**
 * Parse JSON body from Vercel request
 * Safe for admin endpoints - reads stream once with timeout and error handling
 */
export async function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    let resolved = false;
    
    // 10 second timeout for JSON parsing
    const timeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        reject(new Error('Request timeout'));
      }
    }, 10000);

    const cleanup = () => {
      clearTimeout(timeout);
    };

    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', () => {
      if (!resolved) {
        resolved = true;
        cleanup();
        try {
          resolve(body ? JSON.parse(body) : {});
        } catch (error) {
          reject(new Error('Invalid JSON'));
        }
      }
    });

    req.on('error', (error) => {
      if (!resolved) {
        resolved = true;
        cleanup();
        reject(error);
      }
    });

    // Handle empty body case
    req.on('close', () => {
      if (!resolved && body === '') {
        resolved = true;
        cleanup();
        resolve({});
      }
    });
  });
}
