import { getFirebaseAdmin } from './firebaseAdmin.js';

/**
 * Health check endpoint
 * Verifies Firebase Admin SDK is properly initialized
 */
export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Test Firebase initialization
    const { admin } = getFirebaseAdmin();
    const isInitialized = admin && admin.apps.length > 0;

    res.status(200).json({
      status: 'ok',
      firebase: isInitialized,
      timestamp: new Date().toISOString(),
      env: process.env.NODE_ENV || 'production'
    });
  } catch (error) {
    console.error('Health check failed:', error.message);
    res.status(500).json({
      status: 'error',
      firebase: false,
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
}
