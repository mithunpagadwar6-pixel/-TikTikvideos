import admin from 'firebase-admin';

let adminInstance = null;
let bucketInstance = null;

/**
 * Firebase Admin SDK Singleton
 * Prevents re-initialization errors on Vercel serverless functions
 * 
 * CRITICAL: Vercel serverless functions are stateless but may be reused.
 * We use a global variable to cache the Firebase Admin instance across
 * invocations within the same function instance.
 */
export function getFirebaseAdmin() {
  if (adminInstance && bucketInstance) {
    return { admin: adminInstance, bucket: bucketInstance };
  }

  try {
    // Get Firebase service account from environment variable
    const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT;
    if (!serviceAccount) {
      throw new Error('FIREBASE_SERVICE_ACCOUNT environment variable is not set');
    }

    // Parse service account JSON first
    const credentials = JSON.parse(serviceAccount);
    
    // THEN unescape newlines in private_key specifically
    if (credentials.private_key) {
      credentials.private_key = credentials.private_key.replace(/\\n/g, '\n');
    }

    // Get storage bucket name
    const storageBucket = process.env.FIREBASE_STORAGE_BUCKET;
    if (!storageBucket) {
      throw new Error('FIREBASE_STORAGE_BUCKET environment variable is not set');
    }

    // Initialize Firebase Admin SDK (only once)
    if (!admin.apps.length) {
      adminInstance = admin.initializeApp({
        credential: admin.credential.cert(credentials),
        storageBucket: storageBucket
      });
    } else {
      // On warm invocations, reuse existing app
      adminInstance = admin.app();
    }

    // Get storage bucket instance
    bucketInstance = adminInstance.storage().bucket();

    console.log('✅ Firebase Admin initialized successfully');
    return { admin: adminInstance, bucket: bucketInstance };
  } catch (error) {
    console.error('❌ Firebase Admin initialization failed:', error.message);
    throw new Error(`Firebase initialization failed: ${error.message}`);
  }
}

/**
 * Verify Firebase ID token from Authorization header
 * @param {string} authHeader - Authorization header value
 * @returns {Promise<admin.auth.DecodedIdToken>}
 */
export async function verifyFirebaseToken(authHeader) {
  if (!authHeader) {
    throw new Error('No authorization header provided');
  }

  // Remove 'Bearer ' prefix and trim whitespace
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  if (!token) {
    throw new Error('No token provided');
  }

  try {
    const { admin: adminApp } = getFirebaseAdmin();
    const decodedToken = await adminApp.auth().verifyIdToken(token);
    return decodedToken;
  } catch (error) {
    console.error('Token verification failed:', error.message);
    throw new Error('Invalid or expired token');
  }
}

/**
 * Check if user is admin
 * Checks multiple sources: custom claims, userRoles collection, users collection
 * @param {string} userId - User ID to check
 * @returns {Promise<boolean>}
 */
export async function isAdmin(userId) {
  try {
    const { admin: adminApp } = getFirebaseAdmin();
    
    // Check custom claims first (fastest)
    const user = await adminApp.auth().getUser(userId);
    if (user.customClaims && user.customClaims.admin === true) {
      return true;
    }

    // Check Firestore userRoles collection
    const firestore = adminApp.firestore();
    const userRoleDoc = await firestore.collection('userRoles').doc(userId).get();
    if (userRoleDoc.exists && userRoleDoc.data().role === 'admin') {
      return true;
    }

    // Check users collection for isAdmin field
    const userDoc = await firestore.collection('users').doc(userId).get();
    if (userDoc.exists && userDoc.data().isAdmin === true) {
      return true;
    }

    return false;
  } catch (error) {
    console.error('Admin check failed:', error.message);
    return false;
  }
}
